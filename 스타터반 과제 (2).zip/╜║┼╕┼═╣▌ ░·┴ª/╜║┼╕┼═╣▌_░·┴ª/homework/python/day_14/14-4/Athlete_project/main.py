from athlete import Athlete

athlete1 = Athlete("손흥민", "축구", "발롱도로 수상") # 선수 인스턴스 생성

athlete1.display_info() # 선수 정보

athlete1.update_record("은퇴") # 선수 개인 기록 갱신

athlete1.display_info() # 업데이트된 정보 출력