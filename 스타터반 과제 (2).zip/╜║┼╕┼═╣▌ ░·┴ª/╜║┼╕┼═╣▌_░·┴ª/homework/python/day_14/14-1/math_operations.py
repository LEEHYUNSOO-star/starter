import math

def calculate_area(radius):
    return math.pi * (radius ** 2)  # 원의 면적 계산

def calculate_circumference(radius):
    return 2 * math.pi * radius     # 원의 둘레 계산